# MCP 入门包（mcp-starter-bundle）

把第三方服务接进 Agent 的入门合集：最小权限、工具 schema 与测试边界。

## 成员

| 文件夹 | 技能 | 一句话 |
| --- | --- | --- |
| `custom_connector_setup/` | 自定义连接器 / MCP | 用最小权限把第三方服务接入 Agent，并明确工具 schema、错误处理和测试边界。 |

本包目前只有一个技能。高德、滴滴、瑞幸是 MCP 连接器文档，不是技能文件，站内没有对应的技能可以打包；站内也没有第二个与 MCP 相关的技能，所以没有硬凑第二个成员。

## 包内文件

- `README.md`（本文件）
- `custom_connector_setup/SKILL.md`

## 安装

1. 解压本 ZIP。
2. 把 `custom_connector_setup/` 文件夹放进你所用 Agent 的 skills 目录。不同 Agent 的路径不同，以你所用工具的文档为准。
3. 具体用法见 `SKILL.md`。

来源：promangofund.com 技能商店。
