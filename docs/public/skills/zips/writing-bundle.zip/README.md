# 写作包（writing-bundle）

三个写作技能的合集：从成稿清理到开口就说清，再到长文分发。

## 成员

| 文件夹 | 技能 | 一句话 |
| --- | --- | --- |
| `de-ai-writing/` | 去AI味写作 | 按你的口吻写，或把成稿里的机器味清掉。 |
| `zhishuo/` | 直说 | 先给结论，再给理由：一句一件事，数字代替形容词。 |
| `koubo-storyboard/` | 口播分镜 | 把复盘/研报写成口播体长文，并按叙事拐点出证据帧插图；同一剧本分发到视频与 X Article。 |

## 包内文件

- `README.md`（本文件）
- `de-ai-writing/SKILL.md`
- `zhishuo/SKILL.md`、`zhishuo/skill.yaml`、`zhishuo/ATTRIBUTION.md`
- `koubo-storyboard/SKILL.md`、`koubo-storyboard/skill.yaml`、`koubo-storyboard/INSTALL-MUSE.md`

## 安装

1. 解压本 ZIP。
2. 把需要的技能文件夹（例如 `zhishuo/`）放进你所用 Agent 的 skills 目录。不同 Agent 的路径不同，以你所用工具的文档为准。
3. 各技能的具体用法见各自的 `SKILL.md`；口播分镜另附 `INSTALL-MUSE.md`。

来源：promangofund.com 技能商店。
