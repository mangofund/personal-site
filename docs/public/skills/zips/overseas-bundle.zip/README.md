# 出海包（overseas-bundle）

两个出海技能的合集：从拿到首流量到把流量变成付费。

## 成员

| 文件夹 | 技能 | 一句话 |
| --- | --- | --- |
| `haiwai-new-keyword-launch/` | 出海新词上站 | 把待验证的搜索需求转成可发布的落地页，并规划上线后的 SEO/GEO 验证。 |
| `haiwai-monetize-convert/` | 出海变现转化 | 假生成、锚定定价、留存入口与 Stripe 埋点风控，提升付费转化。 |

## 包内文件

- `README.md`（本文件）
- `haiwai-new-keyword-launch/SKILL.md`、`haiwai-new-keyword-launch/references/tools.md`
- `haiwai-monetize-convert/SKILL.md`、`haiwai-monetize-convert/references/tools.md`

## 安装

1. 解压本 ZIP。
2. 把需要的技能文件夹（例如 `haiwai-new-keyword-launch/`）放进你所用 Agent 的 skills 目录。不同 Agent 的路径不同，以你所用工具的文档为准。
3. 各技能的具体用法见各自的 `SKILL.md`。

来源：promangofund.com 技能商店。
